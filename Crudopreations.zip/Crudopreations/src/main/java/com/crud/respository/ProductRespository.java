package com.crud.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.crud.entites.Product;

public interface ProductRespository extends JpaRepository<Product, Integer>{

	Product findByname(String name);

	Product findByprice(double price);

}
