package com.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.entites.Product;
import com.crud.respository.ProductRespository;
@Service
public class Productservice {
	
	@Autowired
    private ProductRespository productrespository;
	public Product saveproduct(Product product) {
		return productrespository.save(product);
		 
	}
	public List<Product> saveAll(List<Product> product){
		return productrespository.saveAll(product);
	}
	
	public Product getProductById(int id) {
		return productrespository.findById(id).orElse(null);
	}
	public List<Product> getallProducts(){
		return  productrespository.findAll();
		}
	public Product getProductByName(String name) {
		return productrespository.findByname(name);
	}
	public String deleteProduct(int id) {
		productrespository.deleteById(id);
		return "Deleted Product "+id;
	}
	public Product updateProduct(Product product) {
		Product existingProduct=productrespository.findById(product.getId()).orElse(null);
		existingProduct.setName(product.getName());
		existingProduct.setPrice(product.getPrice());
		existingProduct.setQuantity(product.getQuantity());
		return productrespository.save(existingProduct); 
	}
	public Product searchByprice(double price) {
		return productrespository.findByprice(price);
	}
	
}
