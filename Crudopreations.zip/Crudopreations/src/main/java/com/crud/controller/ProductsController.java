package com.crud.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.crud.entites.Product;
import com.crud.service.Productservice;


@RestController
public class ProductsController {
	@Autowired
	Productservice service;
	
	@PostMapping("/addproduct")
   public Product addProduct(@RequestBody Product product) {
	   return service.saveproduct(product);
   }
	@PostMapping("/addMultiple")
	public List<Product> addproductAll(@RequestBody List<Product> product){
		return service.saveAll(product);
	}
	@GetMapping("/products")
	public List<Product> findAll(){
		return service.getallProducts();
	}
	@GetMapping("/productsById/{id}")
	public Product findProductById(@PathVariable int id) {
		return service.getProductById(id);
	}
	@GetMapping("/products/{name}")
	public Product findProductByName(@PathVariable  String name) {
		return service.getProductByName(name);
	}
	@GetMapping("/productsByPrice/{price}")
	public Product findByPrice(@PathVariable double price) {
		return service.searchByprice(price);
	}
	@PutMapping("/update")
	public Product updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
		}
	@DeleteMapping("/delete/{id}")
	public String deleteProduct(@PathVariable int id) {
		return "Deleted Row"+service.deleteProduct(id);
	}
	
}
