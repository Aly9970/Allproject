package com.register.registerToken;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegisterTokenApplicationTests {

	@Test
	void contextLoads() {
	}

}
