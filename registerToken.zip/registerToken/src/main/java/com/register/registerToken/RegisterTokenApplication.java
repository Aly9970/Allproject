package com.register.registerToken;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegisterTokenApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegisterTokenApplication.class, args);
	}

}
